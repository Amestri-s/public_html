<?php
    $title = "Action page for panels";
    require "require/head.php";

    $id = $_GET['id'];
    $action = $_GET['action'];
    $ret = $_GET['ret'];

    if(isset($ret)) {
        if($ret == "admin") {
            if(!(isset($_SESSION['perm'])) || !($_SESSION['perm'] >= 4)) {
                header('Location: /scfr/auth/');
                exit;
            }
        }else if ($ret == "mod") {
            if(!(isset($_SESSION['perm'])) || !($_SESSION['perm'] >= 3)) {
                header('Location: /scfr/auth/');
                exit;
            }
        }else {
            header('Location: /scfr/');
        }
    }else {
        header('Location: /scfr/');
    }

    if (isset($action)) {
        if($action == "del"){
            $result = mysqli_query($link, "DELETE FROM members WHERE id=$id");

            header('Location: /scfr/'.$ret.'.php');
        }else if($action == "prom") {
            $perm = mysqli_query($link, 'SELECT perm FROM members WHERE id = "'. $id.'"');
            $permres = mysqli_fetch_array($perm);

            if($permres['perm'] >= 4) {
                $promPerm = 4;
            }else {
                $promPerm = $permres['perm'] + 1;
            }

            $promSQL = 'UPDATE members
            SET perm='.$promPerm.'
            WHERE id='.$id;

            $result = mysqli_query($link, $promSQL);

            header('Location: /scfr/'.$ret.'.php');
        }else if($action == "dem") {
            $perm = mysqli_query($link, 'SELECT perm FROM members WHERE id = "'. $id.'"');
            $permres = mysqli_fetch_array($perm);

            if($permres['perm'] <= 0) {
                $demPerm = 0;
            }else {
                $demPerm = $permres['perm'] - 1;
            }

            $demSQL = 'UPDATE members
            SET perm='.$demPerm.'
            WHERE id='.$id;

            $result = mysqli_query($link, $demSQL);

            header('Location: /scfr/'.$ret.'.php');            
        }
    }else{
        header('Location: /scfr/');
    }
?>