<?php

    $title = "Main application";
    require "require/head.php";

    if(!(isset($_SESSION["loggedin"])) && !($_SESSION["loggedin"] == true)){
        header("location: /scfr/auth/");
        exit;
    } else {
        $scfrApps = mysqli_query($link, 'SELECT id, outcome, outcomeFeedback, createdAt FROM scfrapps WHERE username = "'. $_SESSION['username'].'"');
        $eligible = 0;

        while($res = mysqli_fetch_array($scfrApps)) {
            if ($res['outcome'] == "Denied") {$eligible = 1;} else {$eligible = 0;};
        }
        
        $sfrAppCount = mysqli_num_rows($scfrApps);

        if ($sfrAppCount < 1) {
            $eligible = 1;
        }

        if ($eligible < 1) {
            header("location: /scfr/dashboard.php"); 
        }
    }

    $username = $discordUsername = $robloxProfileLink = $civName = $age = $haveMic = $timeZone = $whyBePart = $experience = $anythingShouldKnow = $readGuidelines = $readApp = $oldEnough = "";

    if($_SERVER["REQUEST_METHOD"] == "POST"){

        //Setup all the values
        $username = $_SESSION['username'];
        $discordUsername = trim($_POST["discordUsername"]);
        $robloxProfileLink = trim($_POST["profileLink"]);
        $civName = trim($_POST["civName"]);
        $age = trim($_POST["age"]);

        if(isset($_POST["hasMic"]) == null) {
            $haveMic = 0;
        } else {
            $haveMic = trim($_POST["hasMic"]);
        }

        $timeZone = trim($_POST["timeZone"]);
        $whyBePart = trim($_POST["whyJoin"]);
        $experience = trim($_POST["experience"]);
        $anythingShouldKnow = trim($_POST["anythingShouldKnow"]);

        if(isset($_POST["readGuidelines"]) == null) {
            $readGuidelines = 0;
        } else {
            $readGuidelines = trim($_POST["readGuidelines"]);
        }

        if(isset($_POST["readApp"]) == null) {
            $readApp = 0;
        } else {
            $readApp = trim($_POST["readApp"]);
        }

        if(isset($_POST["oldEnough"]) == null) {
            $oldEnough = 0;
        } else {
            $oldEnough = trim($_POST["oldEnough"]);
        }

        $sql = "INSERT INTO scfrapps (username, discordUsername, robloxProfileLink, civName, age, doHaveMic, timeZone, whyBePart, experience, anythingWannaKnow, readGuidelines, readApp, oldEnough) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "ssssiissssiii", $username, $discordUsername, $robloxProfileLink, $civName, $age, $haveMic, $timeZone, $whyBePart, $experience, $anythingShouldKnow, $readGuidelines, $readApp, $oldEnough);
                        
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Redirect to dashboard
                header("location: /scfr/dashboard.php");
            } else{
                echo "Something went wrong. Please try again later.";
            }

            // Close statement
            mysqli_stmt_close($stmt);
        }

    }
?>

<form class="border border-light p-5 m-5" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">

    <p class="h4 mb-4 text-center">SCFR Application</p>


    <label for="discordUsername">What is your Discord username?</label>
    <input type="text" id="discordUsername" class="form-control mb-4" placeholder="Amestris#8094" name="discordUsername" required>

    <label for="textInput">Please link your Roblox profile.</label>
    <input type="text" id="textInput" class="form-control mb-4" placeholder="https://www.roblox.com/users/335027300/profile" name="profileLink" required>

    <label for="civName">What is your civilian name? This is who you wish to identify as when on team.</label>
    <input type="text" id="civName" class="form-control mb-4" placeholder="Ben Barns" name="civName" required>

    <label for="age">How old are you?</label>
    <input type="number" id="age" class="form-control mb-4" placeholder="13+" name="age" required>

    <div class="custom-control custom-checkbox mb-4">
        <input type="checkbox" class="custom-control-input" id="hasMic" name="hasMic" value="1">
        <label class="custom-control-label" for="hasMic">Tick, if you have a mic.</label>
    </div>

    <label for="timeZone">What is your timezone?</label>
    <input type="text" id="timeZone" class="form-control mb-4" placeholder="EDT" name="timeZone" required>

    <label for="whyJoin">Why do you want to join SCFR? Detail required. (3-5 sentences reccomended)</label>
    <textarea id="whyJoin" class="form-control mb-4" placeholder="Response that contains 3-5 sentences." name="whyJoin" required></textarea>

    <label for="experience">What experience, if any, do you have?</label>
    <textarea id="experience" class="form-control mb-4" placeholder="Response that contains details of experience in the field." name="experience" required></textarea>

    <label for="anythingShouldKnow">Is there anything we should know before reading your application?</label>
    <textarea id="anythingShouldKnow" class="form-control mb-4" placeholder="Response containing information about self." name="anythingShouldKnow"></textarea>

    <div class="custom-control custom-checkbox mb-4">
        <input type="checkbox" class="custom-control-input" id="readGuidelines" value="1" name="readGuidelines" required>
        <label class="custom-control-label" for="readGuidelines">Tick, if you have read and agree with our and SCRP's guidelines.</label>
    </div>

    <div class="custom-control custom-checkbox mb-4">
        <input type="checkbox" class="custom-control-input" id="readApp" value="1" name="readApp" required>
        <label class="custom-control-label" for="readApp">Tick, if you have read and confirmed that everything you put in this application is accurate and correct.</label>
    </div>

    <div class="custom-control custom-checkbox mb-4">
        <input type="checkbox" class="custom-control-input" id="oldEnough" name="oldEnough" value="1">
        <label class="custom-control-label" for="oldEnough">Tick, if you are 13+.</label>
    </div>

    <button class="btn btn-danger btn-block" type="submit">Send</button>
</form>

<?php
    require "require/footer.php";
?>