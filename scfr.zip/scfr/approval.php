<!DOCTYPE html>
<html lang="en">
<?php
session_start();

if(!(isset($_SESSION['perm'])) || !($_SESSION['perm'] >= 3)) {
  header('Location: /scfr/Auth/');
  exit;
}
$title = "Approval page";
require "require/head.php";

$result = mysqli_query($link, "SELECT id, username, created_at FROM new");


/* close connection */
mysqli_close($link);
?>

  <!-- Start your project here-->  



  <div class="jumbotron animated zoomIn delay-1s">
    <h2 class="display-4 animated fadeIn text-center">Approval queue</h2>
    <p class="lead animated fadeIn text-center">Member stats</p>
    <hr class="my-4 animated fadeIn delay-1s">
    <!-- Card deck -->
<div class="card-deck  animated fadeIn delay-2s">

<!-- Card -->
<div class="card mb-4">

  <!--Card content-->
  <div class="card-body">

    <!--Title-->
    <h4 class="card-title text-center">Registered users</h4>
    <!--Text-->
    <h1 class="text-center"><?php echo $row_cnt_users;?></h1>

  </div>

</div>
<!-- Card -->

<!-- Card -->
<div class="card mb-4">

  <!--Card content-->
  <div class="card-body">

    <!--Title-->
    <h4 class="card-title text-center">Members waiting approval</h4>
    <!--Text-->
    <h1 class="text-center"><?php echo $row_cnt;?></h1>
  </div>

</div>
<!-- Card -->
<table class="table table-striped table-bordered">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Name</th>
      <th scope="col">Created at</th>
      <th scope="col">Approve</th>
    </tr>
  </thead>
  <tbody>
  <?php 
    while($res = mysqli_fetch_array($result)) {         
      echo "<tr>";
      echo "<td>".$res['id']."</td>";
      echo "<td>".$res['username']."</td>";
      echo "<td>".$res['created_at']."</td>";    
      echo "<td><a class='btn btn-green' href=\"edit.php?id=$res[id]\">✓</a>  <a class='btn btn-red' href=\"delete.php?id=$res[id]\" onClick=\"return confirm('Are you sure you want to delete?')\">X</a></td>";        
    }
  ?> 
  </tbody>
</table>

</div>
<!-- Card deck -->
  </div>

<?php
require "require/footer.php";